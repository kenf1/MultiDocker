## revdepcheck results

We checked 241 reverse dependencies (239 from CRAN + 2 from Bioconductor), comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 0 new problems
 * We failed to check 3 packages

Issues with CRAN packages are summarised below.

### Failed to check

* hydflood   (NA)
* loon.shiny (NA)
* loon.tourr (NA)
