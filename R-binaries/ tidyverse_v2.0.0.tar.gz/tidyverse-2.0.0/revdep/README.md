# Revdeps

## Failed to check (5)

|package      |version |error |warning |note |
|:------------|:-------|:-----|:-------|:----|
|covidmx      |?       |      |        |     |
|hydflood     |0.5.2   |1     |        |     |
|loon.shiny   |?       |      |        |     |
|loon.tourr   |?       |      |        |     |
|wrappedtools |?       |      |        |     |

