# Revdeps

## Failed to check (1)

|package |version |error |warning |note |
|:-------|:-------|:-----|:-------|:----|
|conos   |1.4.5   |1     |        |     |

## New problems (1)

|package                        |version |error  |warning |note |
|:------------------------------|:-------|:------|:-------|:----|
|[rbioapi](problems.md#rbioapi) |0.7.4   |__+1__ |        |     |

