#Vignettes that depend on internet access have been precompiled:

library(knitr)
knit("vignettes/json-apis.Rmd.orig", "vignettes/json-apis.Rmd")
knit("vignettes/json-paging.Rmd.orig", "vignettes/json-paging.Rmd")
