## revdepcheck results

We checked 369 reverse dependencies (367 from CRAN + 2 from Bioconductor), comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 0 new problems
 * We failed to check 2 packages

Issues with CRAN packages are summarised below.

### Failed to check

* ctsem   (NA)
* nlmixr2 (NA)
