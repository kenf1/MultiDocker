#' @param workspace a [Workspace] object, the current workspace
