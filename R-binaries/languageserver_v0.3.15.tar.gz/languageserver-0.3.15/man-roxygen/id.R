#' @param id a numeric, the id of the process that started the server
