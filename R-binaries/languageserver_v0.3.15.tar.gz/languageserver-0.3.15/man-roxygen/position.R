#' @param position a [position] object
