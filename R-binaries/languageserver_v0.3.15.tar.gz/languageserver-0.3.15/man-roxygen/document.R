#' @param document a character, the contents of the document
