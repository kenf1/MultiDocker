#' @param uri a character, the path to a file as defined by [RFC 3986](https://tools.ietf.org/html/rfc3986)
