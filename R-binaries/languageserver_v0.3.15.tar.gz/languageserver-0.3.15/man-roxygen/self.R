#' @param self a [LanguageServer] object
