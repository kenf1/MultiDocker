#' @param params a [text_document_position_params] object
