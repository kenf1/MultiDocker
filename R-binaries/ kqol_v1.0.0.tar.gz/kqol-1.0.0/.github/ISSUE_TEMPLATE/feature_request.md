---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: kenf1

---

**Description of feature request**
A clear and concise description of what the feature request is.

**Suggestions on implementation**
Provide any ideas on how to implement feature into package.
